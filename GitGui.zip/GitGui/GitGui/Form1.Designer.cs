﻿
namespace GitGui
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.username = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.workingPath = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.clone = new System.Windows.Forms.Button();
            this.txtCloneUrl = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtLogs = new System.Windows.Forms.RichTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnCommit = new System.Windows.Forms.Button();
            this.btnPush = new System.Windows.Forms.Button();
            this.btnPull = new System.Windows.Forms.Button();
            this.btnSavePath = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtAllChanges = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPull = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPush = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCommit = new System.Windows.Forms.ToolStripMenuItem();
            this.logsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.authorLogsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.onelineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mediumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nameStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nameStatusOnelineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnClearLogs = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(7, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(188, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Login and Init";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.email);
            this.groupBox1.Controls.Add(this.username);
            this.groupBox1.Location = new System.Drawing.Point(12, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 144);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login to git";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Username";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(7, 79);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(187, 20);
            this.email.TabIndex = 2;
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(7, 36);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(188, 20);
            this.username.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnSavePath);
            this.groupBox2.Controls.Add(this.workingPath);
            this.groupBox2.Location = new System.Drawing.Point(219, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(674, 52);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Working Project Path";
            // 
            // workingPath
            // 
            this.workingPath.Location = new System.Drawing.Point(7, 20);
            this.workingPath.Name = "workingPath";
            this.workingPath.Size = new System.Drawing.Size(579, 20);
            this.workingPath.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.clone);
            this.groupBox3.Controls.Add(this.txtCloneUrl);
            this.groupBox3.Location = new System.Drawing.Point(12, 27);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 77);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Clone Project";
            // 
            // clone
            // 
            this.clone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.clone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clone.ForeColor = System.Drawing.Color.White;
            this.clone.Location = new System.Drawing.Point(7, 47);
            this.clone.Name = "clone";
            this.clone.Size = new System.Drawing.Size(185, 23);
            this.clone.TabIndex = 1;
            this.clone.Text = "Clone";
            this.clone.UseVisualStyleBackColor = false;
            this.clone.Click += new System.EventHandler(this.clone_Click);
            // 
            // txtCloneUrl
            // 
            this.txtCloneUrl.Location = new System.Drawing.Point(7, 20);
            this.txtCloneUrl.Name = "txtCloneUrl";
            this.txtCloneUrl.Size = new System.Drawing.Size(185, 20);
            this.txtCloneUrl.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.btnClearLogs);
            this.groupBox4.Controls.Add(this.txtLogs);
            this.groupBox4.Location = new System.Drawing.Point(12, 405);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(881, 169);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Git logs";
            // 
            // txtLogs
            // 
            this.txtLogs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtLogs.Location = new System.Drawing.Point(7, 20);
            this.txtLogs.Name = "txtLogs";
            this.txtLogs.Size = new System.Drawing.Size(868, 143);
            this.txtLogs.TabIndex = 0;
            this.txtLogs.Text = "";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.btnCommit);
            this.groupBox5.Controls.Add(this.btnPush);
            this.groupBox5.Controls.Add(this.btnPull);
            this.groupBox5.Location = new System.Drawing.Point(219, 85);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(674, 53);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Actions";
            // 
            // btnCommit
            // 
            this.btnCommit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.btnCommit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCommit.ForeColor = System.Drawing.Color.White;
            this.btnCommit.Location = new System.Drawing.Point(87, 20);
            this.btnCommit.Name = "btnCommit";
            this.btnCommit.Size = new System.Drawing.Size(75, 23);
            this.btnCommit.TabIndex = 2;
            this.btnCommit.Text = "[dot] Commit";
            this.btnCommit.UseVisualStyleBackColor = false;
            this.btnCommit.Click += new System.EventHandler(this.btnCommit_Click);
            // 
            // btnPush
            // 
            this.btnPush.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.btnPush.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPush.ForeColor = System.Drawing.Color.White;
            this.btnPush.Location = new System.Drawing.Point(168, 20);
            this.btnPush.Name = "btnPush";
            this.btnPush.Size = new System.Drawing.Size(75, 23);
            this.btnPush.TabIndex = 1;
            this.btnPush.Text = "Push";
            this.btnPush.UseVisualStyleBackColor = false;
            this.btnPush.Click += new System.EventHandler(this.btnPush_Click);
            // 
            // btnPull
            // 
            this.btnPull.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.btnPull.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPull.ForeColor = System.Drawing.Color.White;
            this.btnPull.Location = new System.Drawing.Point(7, 20);
            this.btnPull.Name = "btnPull";
            this.btnPull.Size = new System.Drawing.Size(75, 23);
            this.btnPull.TabIndex = 0;
            this.btnPull.Text = "Pull";
            this.btnPull.UseVisualStyleBackColor = false;
            this.btnPull.Click += new System.EventHandler(this.btnPull_Click);
            // 
            // btnSavePath
            // 
            this.btnSavePath.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.btnSavePath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSavePath.ForeColor = System.Drawing.Color.White;
            this.btnSavePath.Location = new System.Drawing.Point(593, 19);
            this.btnSavePath.Name = "btnSavePath";
            this.btnSavePath.Size = new System.Drawing.Size(75, 23);
            this.btnSavePath.TabIndex = 1;
            this.btnSavePath.Text = "Save Path";
            this.btnSavePath.UseVisualStyleBackColor = false;
            this.btnSavePath.Click += new System.EventHandler(this.btnSavePath_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.txtAllChanges);
            this.groupBox6.Location = new System.Drawing.Point(219, 144);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(674, 255);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "All Changes";
            // 
            // txtAllChanges
            // 
            this.txtAllChanges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtAllChanges.Location = new System.Drawing.Point(7, 19);
            this.txtAllChanges.Name = "txtAllChanges";
            this.txtAllChanges.ReadOnly = true;
            this.txtAllChanges.Size = new System.Drawing.Size(661, 224);
            this.txtAllChanges.TabIndex = 0;
            this.txtAllChanges.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.menuGit,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(904, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // menuGit
            // 
            this.menuGit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuPull,
            this.menuCommit,
            this.menuPush,
            this.logsToolStripMenuItem});
            this.menuGit.Name = "menuGit";
            this.menuGit.Size = new System.Drawing.Size(34, 20);
            this.menuGit.Text = "Git";
            // 
            // menuPull
            // 
            this.menuPull.Name = "menuPull";
            this.menuPull.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.P)));
            this.menuPull.Size = new System.Drawing.Size(180, 22);
            this.menuPull.Text = "Pull";
            this.menuPull.Click += new System.EventHandler(this.menuPull_Click);
            // 
            // menuPush
            // 
            this.menuPush.Name = "menuPush";
            this.menuPush.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.O)));
            this.menuPush.Size = new System.Drawing.Size(180, 22);
            this.menuPush.Text = "Push";
            this.menuPush.Click += new System.EventHandler(this.menuPush_Click);
            // 
            // menuCommit
            // 
            this.menuCommit.Name = "menuCommit";
            this.menuCommit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.menuCommit.Size = new System.Drawing.Size(180, 22);
            this.menuCommit.Text = "Commit";
            // 
            // logsToolStripMenuItem
            // 
            this.logsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.authorLogsToolStripMenuItem,
            this.onelineToolStripMenuItem,
            this.shortToolStripMenuItem,
            this.mediumToolStripMenuItem,
            this.nameStatusToolStripMenuItem,
            this.nameStatusOnelineToolStripMenuItem});
            this.logsToolStripMenuItem.Name = "logsToolStripMenuItem";
            this.logsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.logsToolStripMenuItem.Text = "Logs";
            // 
            // authorLogsToolStripMenuItem
            // 
            this.authorLogsToolStripMenuItem.Name = "authorLogsToolStripMenuItem";
            this.authorLogsToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.authorLogsToolStripMenuItem.Text = "Author logs";
            // 
            // onelineToolStripMenuItem
            // 
            this.onelineToolStripMenuItem.Name = "onelineToolStripMenuItem";
            this.onelineToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.onelineToolStripMenuItem.Text = "Oneline";
            // 
            // shortToolStripMenuItem
            // 
            this.shortToolStripMenuItem.Name = "shortToolStripMenuItem";
            this.shortToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.shortToolStripMenuItem.Text = "Short";
            // 
            // mediumToolStripMenuItem
            // 
            this.mediumToolStripMenuItem.Name = "mediumToolStripMenuItem";
            this.mediumToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.mediumToolStripMenuItem.Text = "Medium";
            // 
            // nameStatusToolStripMenuItem
            // 
            this.nameStatusToolStripMenuItem.Name = "nameStatusToolStripMenuItem";
            this.nameStatusToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.nameStatusToolStripMenuItem.Text = "Name Status";
            // 
            // nameStatusOnelineToolStripMenuItem
            // 
            this.nameStatusOnelineToolStripMenuItem.Name = "nameStatusOnelineToolStripMenuItem";
            this.nameStatusOnelineToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.nameStatusOnelineToolStripMenuItem.Text = "Name Status Oneline";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // btnClearLogs
            // 
            this.btnClearLogs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(159)))), ((int)(((byte)(239)))));
            this.btnClearLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearLogs.ForeColor = System.Drawing.Color.White;
            this.btnClearLogs.Location = new System.Drawing.Point(805, 0);
            this.btnClearLogs.Name = "btnClearLogs";
            this.btnClearLogs.Size = new System.Drawing.Size(75, 27);
            this.btnClearLogs.TabIndex = 1;
            this.btnClearLogs.Text = "Clear";
            this.btnClearLogs.UseVisualStyleBackColor = false;
            this.btnClearLogs.Click += new System.EventHandler(this.btnClearLogs_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(81, 579);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(737, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "NOT: BU UYGULAMA PROJENİZİN ANA DİZİNİNDE BULUNMASI GEREKMEKTEDİR. AKSİ TAKDİRDE " +
    "DİZİN BULUNAMADI HATASI ALACAKSINIZ.\r\n";
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(904, 601);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Git Gui";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.Form1_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.Form1_DragEnter);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox workingPath;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button clone;
        private System.Windows.Forms.TextBox txtCloneUrl;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RichTextBox txtLogs;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnCommit;
        private System.Windows.Forms.Button btnPush;
        private System.Windows.Forms.Button btnPull;
        private System.Windows.Forms.Button btnSavePath;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RichTextBox txtAllChanges;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuGit;
        private System.Windows.Forms.ToolStripMenuItem menuPull;
        private System.Windows.Forms.ToolStripMenuItem menuCommit;
        private System.Windows.Forms.ToolStripMenuItem menuPush;
        private System.Windows.Forms.ToolStripMenuItem logsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorLogsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem onelineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mediumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nameStatusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nameStatusOnelineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Button btnClearLogs;
        private System.Windows.Forms.Label label3;
    }
}

