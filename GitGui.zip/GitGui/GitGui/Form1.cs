﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitGui
{
    public partial class Form1 : Form
    {

        string[] geciciDizineEklenenler;
        public Form1()
        {
            InitializeComponent();
        }


        public static string CommandOutput(string command,string workingDirectory = null)
        {
            try
            {
                ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd", "/c " + command);

                procStartInfo.RedirectStandardError = procStartInfo.RedirectStandardInput = procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                procStartInfo.CreateNoWindow = true;
                if (null != workingDirectory)
                {
                    procStartInfo.WorkingDirectory = workingDirectory;
                }

                Process proc = new Process();
                proc.StartInfo = procStartInfo;
                proc.Start();

                StringBuilder sb = new StringBuilder();
                proc.OutputDataReceived += delegate (object sender, DataReceivedEventArgs e)
                {
                    sb.AppendLine(e.Data);
                };
                proc.ErrorDataReceived += delegate (object sender, DataReceivedEventArgs e)
                {
                    sb.AppendLine(e.Data);
                };

                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();
                proc.WaitForExit();
                return sb.ToString();
            }
            catch (Exception objException)
            {
                return $"Error in command: {command}, {objException.Message}\n";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(CommandOutput("git status", @"C:\xampp\htdocs\kurumsal-online-etkinlik"), "");
            string u = "git config --global user.name \""+ this.username.Text+"\"";
            string ee = "git config --global user.email \"" + email.Text + "\"";
            txtLogs.Text += CommandOutput(u, workingPath.Text);
            txtLogs.Text += CommandOutput(ee, workingPath.Text);
            txtLogs.Text += CommandOutput("git init", workingPath.Text);
            //https://www.codegrepper.com/code-examples/shell/how+to+git+login+in+terminal

            saveData(workingPath.Text, username.Text, email.Text, txtCloneUrl.Text);
        }

        private void clone_Click(object sender, EventArgs e)
        {
            txtLogs.Text += "Clone isteğinde bulunuldu, lütfen bekleyiniz...\n";
            txtLogs.Text += CommandOutput("git clone "+ txtCloneUrl.Text, workingPath.Text);
            saveData(workingPath.Text, username.Text, email.Text, txtCloneUrl.Text);
        }

        private void btnPull_Click(object sender, EventArgs e)
        {
            txtLogs.Text += "Pull isteğinde bulunuldu, lütfen bekleyiniz...\n";
            txtLogs.Text += CommandOutput("git pull", workingPath.Text);
        }

        private void btnPush_Click(object sender, EventArgs e)
        {
            txtLogs.Text += "Push isteğinde bulunuldu, lütfen bekleyiniz...\n";
            txtLogs.Text += CommandOutput("git push", workingPath.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"data.txt");
            try
            {
                string[] files = File.ReadAllLines(path);
                foreach (string f in files)
                {
                    string[] s = f.Split('=');
                    if(s[0]== "[WorkingProjectPath]")
                    {
                        workingPath.Text = s[1];
                    }else if(s[0]== "[Username]")
                    {
                        username.Text = s[1];
                    }
                    else if (s[0] == "[Email]")
                    {
                        email.Text = s[1];
                    }
                    else if (s[0] == "[CloneProject]")
                    {
                        txtCloneUrl.Text = s[1];
                    }
                }
            }
            catch(FileNotFoundException e1){

            }
            
        }

        private void btnSavePath_Click(object sender, EventArgs e)
        {
            saveData(workingPath.Text, username.Text, email.Text, txtCloneUrl.Text);
        }

        public void saveData(string workingProjectPath,string username,string email,string cloneProject)
        {
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"data.txt");
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[WorkingProjectPath]="+ workingProjectPath);
            sb.AppendLine("[Username]=" + username);
            sb.AppendLine("[Email]=" + email);
            sb.AppendLine("[CloneProject]=" + cloneProject);
            File.WriteAllText(path, sb.ToString());
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            txtAllChanges.Text += "===== " + DateTime.Now.ToString() + " =====\n";
            string[] filePaths = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            foreach (string item in filePaths)
            {
                txtAllChanges.Text += item+"\n";
                
                File.Copy(@item, workingPath.Text + "/" + Path.GetFileName(item));
            }
            geciciDizineEklenenler = filePaths;
            txtAllChanges.Text += "===== Sürükleyip taşıdığınız bu klasörler seçildi.  =====\n";
            txtAllChanges.Text += "===== Pull ediniz ardından Commit ve Push edin. =====\n";
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormHelp help = new FormHelp();
            help.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menuPull_Click(object sender, EventArgs e)
        {
            txtLogs.Text += "Pull isteğinde bulunuldu, lütfen bekleyiniz...\n";
            txtLogs.Text += CommandOutput("git pull", workingPath.Text);
        }

        private void menuPush_Click(object sender, EventArgs e)
        {
            txtLogs.Text += "Push isteğinde bulunuldu, lütfen bekleyiniz...\n";
            txtLogs.Text += CommandOutput("git push", workingPath.Text);
        }

        private void btnClearLogs_Click(object sender, EventArgs e)
        {
            txtLogs.Clear();
        }

        private void btnCommit_Click(object sender, EventArgs e)
        {
            string deger = Microsoft.VisualBasic.Interaction.InputBox("", "Commit mesajı");
            txtLogs.Text += "Commit isteğinde bulunuldu, lütfen bekleyiniz...\n";
            txtLogs.Text += "[dot] Commit klasörde bulunan tüm dosya ve klasörleri add ile ekler...\n";
            try
            {
                foreach (string item in geciciDizineEklenenler)
                {
                    string degistir = "\\" + Path.GetFileName(item); //Path.GetFullPath(workingPath.Text) +
                    degistir = degistir.Replace("\\", "");
                    degistir = degistir.Replace(":", "");

                    txtLogs.Text += CommandOutput("git add .");
                    txtLogs.Text += CommandOutput("git rm -r");
                }
                txtLogs.Text += CommandOutput("git commit -m \"" + deger + "\"");
                MessageBox.Show("Commit işlendi");
            }
            catch(Exception e2)
            {

            }
            
        }
    }
}
